#!/usr/bin/env python3
# -*- mode: python; coding: utf-8; python-indent-offset: 2; indent-tabs-mode: nil -*-

"""
doc.py - usage and help text for the Harmony 'check' tool

Grammar (informal):

  <prog> <command>* [<other>]

  <command>   :: <help> | <no_other> | <has_other>

  <help>      :: version | help | usage
  <no_other>  :: environment
  <has_other> :: structure | import | export | suspicious | addendum | all
"""

from __future__ import annotations

import meta
import os
import sys
from typing import TextIO


def prog_name() -> str:
  """
  Return the program name as invoked by the user.

  Typically:
    - basename(sys.argv[0]) when running from the shell.
    - Falls back to 'check' if argv[0] is empty.
  """
  raw = sys.argv[0] if sys.argv and sys.argv[0] else "check"
  base = os.path.basename(raw) or raw
  return base


def _usage_text(prog: str) -> str:
  return f"""\
Usage:
  {prog} <command>* [<other>]

Where:
  <command>   :: <help> | <no_other> | <has_other>

  <help>      :: version | help | usage
  <no_other>  :: environment
  <has_other> :: structure | import | export | suspicious | addendum | all
"""

def _help_text(prog: str) -> str:
  return f"""\
{prog} - Harmony skeleton integrity and metadata checker

Syntax:
  {prog} <command>* [<other>]

Where:
  <other>   :: path
  <command> :: <help> | <no_other> | <has_other>

  <help>      :: version | help | usage
  <no_other>  :: environment
  <has_other> :: structure | import | export | suspicious | addendum | all

Argument rules (informal):
  1. <help> commands are processed first, and then the program returns.
     Hence if any help commands are present, the remaining commands
     are ignored.

  2. We assume {prog} is run within the Harmony skeleton, or a skeleton
     derived directly from it. This is the 'default skeleton', or simply 'A'.

  3. The <other> path is the directory of a project that is assumed to
     be built upon the default skeleton. This second project root is
     called 'B'.

  4. If none of the commands require an <other> path, then <other>
     must not be given. If at least one command requires <other>, then
     <other> is required. Commands that require a path are called
     <has_other> commands.

  5. Implementation detail:
       All arguments except the final one are interpreted strictly as
       command tokens. If any of those are <has_other>, the final argument
       is taken as <other>. If none of the earlier tokens are <has_other>,
       the final argument is also treated as a command token.

Roots:
  A = Skeleton project root (auto-detected). Usually the Harmony skeleton.
  B = <other> project root (supplied when required).

{prog} compares A with B. Differences may come from:
  - edits to the skeleton itself,
  - edits to skeleton files inside B,
  - or new files/directories added to B.
Conceptually, A and B are any two non-overlapping directory trees.

Command semantics:
  structure
    - Report directory-structure differences:
        directories present in A that are missing in B or not
        directories in B.
    - Output: table of such directories.

  import
    - Update A from B using only "in-between newer" files:
        * files in B that lie in the 'in-between' region relative to A, and
        * are newer than A or absent from A.
    - Also emits:
        * directories to create in A,
        * files to copy (B -> A),
        * nodes that cannot be handled automatically (type mismatches,
          constrained nodes, non-file/dir nodes).
    - Direction: B -> A

  export
    - Update B from A:
        * files in A newer than B at the same path,
        * files present in A but missing in B.
    - Also emits:
        * directories to create in B,
        * files to copy (A -> B),
        * nodes that cannot be handled automatically.
    - Direction: A -> B

  suspicious
    - Report B nodes that lie "in-between" Harmony leaves:
        under a directory from A, but not under any leaf directory of A.
    - Indicates questionable placements or missing skeleton structure.

  addendum
    - Report B nodes located "below" Harmony leaf directories:
        project-specific additions placed in proper extension points.

  all
    - Run: structure, import, export, suspicious, addendum (in that order).

Notes:
  - tree_dict traversal respects a simplified .gitignore model plus
    always-ignored patterns (e.g. '.git').
  - Timestamps are formatted via the Z helper in UTC (ISO 8601).
"""

def print_usage(
  stream: TextIO | None = None
) -> None:
  """
  Print the usage text to the given stream (default: sys.stdout),
  using the actual program name as invoked.
  """
  if stream is None:
    stream = sys.stdout

  text = _usage_text(prog_name())
  stream.write(text)
  if not text.endswith("\n"):
    stream.write("\n")


def print_help(
  stream: TextIO | None = None
) -> None:
  """
  Print the help text to the given stream (default: sys.stdout),
  using the actual program name as invoked.
  """
  if stream is None:
    stream = sys.stdout

  utext = _usage_text(prog_name())
  htext = _help_text(prog_name())

  stream.write(utext)
  if not utext.endswith("\n"):
    stream.write("\n")

  stream.write("\n")
  stream.write(htext)
  if not htext.endswith("\n"):
    stream.write("\n")
