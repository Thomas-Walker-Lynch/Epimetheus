#!/usr/bin/env python3
# -*- mode: python; coding: utf-8; python-indent-offset: 2; indent-tabs-mode: nil -*-

"""
CLI.py - Harmony skeleton checker

Grammar (informal):

  check <command>* [<other>]

  <command>   :: <help> | <no_other> | <has_other>

  <help>      :: version | help | usage
  <no_other>  :: environment
  <has_other> :: structure | import | export | suspicious | addendum | all

Commands are sorted into three sets:
  1. HELP_COMMANDS
  2. NO_OTHER_COMMANDS
  3. HAS_OTHER_COMMANDS

At runtime, argv commands are classified into four lists:
  1. help_list
  2. no_other_list
  3. has_other_list
  4. unclassified_list

If the meta debug set contains the tag "print_command_lists", these four lists
are printed.

If 'environment' appears in no_other_list, the meta.printenv() helper
is invoked to print the environment.

For <has_other> commands we compare:

  A = Harmony skeleton tree_dict
  B = <other> project tree_dict (path is the last argv token when any
      <has_other> is present before it).
"""

from __future__ import annotations

import os
import sys
from typing import Sequence

import command
import doc
import Harmony
import meta
import skeleton

# meta.debug_set("print_command_lists")

# Command tag sets (classification universe)
HELP_COMMANDS: set[str] = set([
  "version"
  ,"help"
  ,"usage"
])

NO_OTHER_COMMANDS: set[str] = set([
  "environment"
])

HAS_OTHER_COMMANDS: set[str] = set([
  "structure"
  ,"import"
  ,"export"
  ,"suspicious"
  ,"addendum"
  ,"all"
])


def command_type(arg: str) -> str:
  """
  Classify a single command token.

  Returns:
    "Help"         if arg is a help command
    "NoOther"      if arg is a no_other command
    "HasOther"     if arg is a has_other command
    "UnClassified" otherwise
  """
  if arg in HELP_COMMANDS:
    return "Help"

  if arg in NO_OTHER_COMMANDS:
    return "NoOther"

  if arg in HAS_OTHER_COMMANDS:
    return "HasOther"

  return "UnClassified"


def print_command_lists(
  help_list: list[str]
  ,no_other_list: list[str]
  ,has_other_list: list[str]
  ,unclassified_list: list[str]
) -> None:
  """
  Print the four classified command lists derived from argv.
  """
  print("help_list:", help_list)
  print("no_other_list:", no_other_list)
  print("has_other_list:", has_other_list)
  print("unclassified_list:", unclassified_list)


def CLI(argv: Sequence[str] | None = None) -> int:
  """
  CLI entrypoint.

  Responsibilities:
    1. Accept argv (or sys.argv[1:] by default).
    2. Classify arguments using command_type(), with the last argument
       treated specially to avoid aliasing.
    3. Invoke behaviors implied by the commands.
    4. Return integer status code.

  Argument interpretation:

    Let argv = [a0, a1, ..., aN-1].

    - If N == 0:
        no commands; nothing to do.

    - If N >= 1:
        * Classify a0..aN-2.
          - If any are UnClassified -> error.

        * If any <has_other> appear in a0..aN-2:
            - aN-1 is treated as <other> path (B_root), not classified.

        * If no <has_other> appear in a0..aN-2:
            - Classify aN-1:
                - If UnClassified -> error (unknown command).
                - If HasOther    -> error (other path not specified).
                - Else           -> added to Help / NoOther lists.
  """
  if argv is None:
    argv = sys.argv[1:]

  # No arguments: print usage and exit with status 1.
  if len(argv) == 0:
    doc.print_usage()
    return 1

  # No arguments: nothing to do (could later decide to print usage).
  if len(argv) == 0:
    return 0

  # Split into head (all but last) and last argument
  head = argv[:-1]
  last = argv[-1]

  help_list: list[str] = []
  no_other_list: list[str] = []
  has_other_list: list[str] = []
  unclassified_list: list[str] = []

  # 1. Classify head tokens
  for arg in head:
    ct = command_type(arg)

    if ct == "Help":
      help_list.append(arg)
    elif ct == "NoOther":
      no_other_list.append(arg)
    elif ct == "HasOther":
      has_other_list.append(arg)
    else:
      unclassified_list.append(arg)

  # Any unclassified in the head is an error
  if len(unclassified_list) > 0:
    first_bad = unclassified_list[0]
    print(f"Unrecognized command: {first_bad}")
    return 5

  head_has_other = (len(has_other_list) > 0)

  B_root: str | None = None

  if head_has_other:
    # 2A. Any <has_other> in head -> last arg is always <other> path.
    B_root = os.path.abspath(last)
  else:
    # 2B. No <has_other> in head -> classify last.
    ct = command_type(last)

    if ct == "UnClassified":
      print(f"Unrecognized command: {last}")
      return 5

    if ct == "HasOther":
      print("Other path not specified for has_other command(s).")
      return 6

    if ct == "Help":
      help_list.append(last)
    elif ct == "NoOther":
      no_other_list.append(last)
    # ct cannot be HasOther here due to earlier check.

  if meta.debug_has("print_command_lists"):
    print_command_lists(
      help_list
      ,no_other_list
      ,has_other_list
      ,unclassified_list
    )

  # Help handling
  if len(help_list) > 0:
    if "version" in help_list:
      meta.version_print()
    if "usage" in help_list:
      doc.print_usage()
    if "help" in help_list:
      doc.print_help()
    return 1

  ret_val = 0

  # No-other commands (environment, etc.)
  if "environment" in no_other_list:
    env_status = meta.printenv()
    if env_status != 0:
      ret_val = env_status

  # If we still have no has_other commands, we are done.
  # (Example: just "environment", or just "help/usage".)
  if len(has_other_list) == 0:
    return ret_val

  # At this point we know:
  #   - has_other_list is non-empty
  #   - B_root must have been set (head_has_other was True)
  if B_root is None:
    print("Internal error: B_root not set despite has_other commands.")
    return 7

  if not os.path.isdir(B_root):
    print(f"Other project path is not a directory: {B_root}")
    return 4

  # Determine Harmony root (A_root)
  status, A_root = Harmony.where()

  if status == "not-found":
    print("Harmony project not found; normally this command is run from within Harmony.")
    return 3

  if status == "different":
    print("Seems we are not running in the Harmony project, will exit.")
    return 2

  # Build tree_dicts for A (Harmony) and B (other project)
  A_tree = skeleton.tree_dict_make(A_root, None)
  B_tree = skeleton.tree_dict_make(B_root, None)

  # Dispatch the <has_other> commands
  cmd_status = command.dispatch(
    has_other_list
    ,A_tree
    ,B_tree
    ,A_root
    ,B_root
  )

  if cmd_status != 0:
    ret_val = cmd_status

  return ret_val


if __name__ == "__main__":
  raise SystemExit(CLI())
