#!/usr/bin/env python3
# -*- mode: python; coding: utf-8; python-indent-offset: 2; indent-tabs-mode: nil -*-

"""
locate the project root
"""

from __future__ import annotations

import meta
import os
import sys
from typing import Any, Callable, Dict

# where
#
# Context / assumptions:
#   1. This module lives somewhere under the Harmony tree, for example:
#        /.../Harmony/tool/skeleton/skeleton.py
#   2. CLI.py is run from somewhere inside the same tree (or a clone).
#
# Search behavior:
#   1. Start from the directory containing this file.
#   2. Walk upward towards the filesystem root, with limits:
#      a) Do not move up more than 5 levels.
#      b) Stop immediately if the current directory contains a
#         '.git' subdirectory.
#
# Result classification:
#   status is one of:
#     'found'      -> we found a directory whose basename is 'Harmony'
#     'different'  -> we stopped at a directory that has a '.git'
#                     subdirectory, but its basename is not 'Harmony'
#     'not-found'  -> we hit the 5-level limit or filesystem root
#                     without finding 'Harmony' or a '.git' directory
#
# Path:
#   - In all cases, the returned path is the last directory inspected:
#       * the 'Harmony' directory (status 'found'), or
#       * the directory with '.git' (status 'different'), or
#       * the directory at the 5-level limit / filesystem root
#         (status 'not-found').
#
# Debug printing:
#   - If meta.debug_has("print_Harmony_root") is true, print:
#       * "The Harmony project root found at: {path}"
#         when status == 'found'
#       * "Harmony not found, but found: {path}"
#         when status == 'different'
#       * "Harmony not found."
#         when status == 'not-found'
def where() -> tuple[str, str]:
  """
  Locate the Harmony root (or best guess).

  Returns:
    (status, path)
  """
  here = os.path.abspath(__file__)
  d = os.path.dirname(here)

  harmony_root = None
  status = "not-found"

  max_up = 5
  steps = 0

  while True:
    base = os.path.basename(d)

    # Case 1: exact 'Harmony' directory name
    if base == "Harmony":
      harmony_root = d
      status = "found"
      break

    # Case 2: stop at a directory that has a '.git' subdirectory
    git_dir = os.path.join(d, ".git")
    if os.path.isdir(git_dir):
      harmony_root = d
      if base == "Harmony":
        status = "found"
      else:
        status = "different"
      break

    parent = os.path.dirname(d)

    # Stop if we hit filesystem root
    if parent == d:
      harmony_root = d
      status = "not-found"
      break

    steps += 1
    if steps > max_up:
      # Reached search depth limit; last inspected directory is d
      harmony_root = d
      status = "not-found"
      break

    d = parent

  if harmony_root is None:
    # Extremely defensive; in practice harmony_root will be set above.
    harmony_root = d

  root_base = os.path.basename(harmony_root)

  # Warning to stderr if we are not literally in a 'Harmony' directory
  if root_base != "Harmony":
    sys.stderr.write(
      f"WARNING: Harmony root basename is '{root_base}', expected 'Harmony'.\n"
    )

  if meta.debug_has("print_Harmony_root"):
    if status == "found":
      print(f"The Harmony project root found at: {harmony_root}")
    elif status == "different":
      print(f"Harmony not found, but found: {harmony_root}")
    else:
      print("Harmony not found.")

  return status, harmony_root

def test_where() -> int:
  """
  Simple test that prints the Harmony root using the debug flag.
  """
  meta.debug_set("print_Harmony_root")
  status, _root = where()
  return 0 if status != "not-found" else 1

