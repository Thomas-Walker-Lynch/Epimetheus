#!/usr/bin/env python3
# -*- mode: python; coding: utf-8; python-indent-offset: 2; indent-tabs-mode: nil -*-

"""
load_command_module.py - locate and import Python command modules from $PATH

Behavior:
  1. Search $PATH for an executable with the given command name.
  2. Prefer a path containing '/incommon/'.
  3. If only /usr/bin/<command> is found, raise an error saying we were
     looking for the incommon version.
  4. Import the chosen script as a Python module, even if it has no .py
     extension, by forcing a SourceFileLoader.
"""

from __future__ import annotations

import importlib.util
import os
from importlib.machinery import SourceFileLoader
from types import ModuleType
from typing import List


def _find_command_candidates(command_name: str) -> List[str]:
  """
  Return a list of absolute paths to executables named `command_name`
  found on $PATH.
  """
  paths: list[str] = []

  path_env = os.environ.get("PATH", "")
  for dir_path in path_env.split(os.pathsep):
    if not dir_path:
      continue
    candidate = os.path.join(dir_path, command_name)
    if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
      paths.append(os.path.realpath(candidate))

  return paths


def load_command_module(command_name: str) -> ModuleType:
  """
  Locate an executable named `command_name` on $PATH and load it
  as a Python module.

  Selection policy:
    1. Prefer any path containing '/incommon/'.
    2. If only /usr/bin/<command_name> candidates exist, raise an error
       saying we were looking for the incommon version.
    3. If no candidate is found, raise an error.

  Implementation detail:
    Because the incommon command may lack a .py suffix, we explicitly
    construct a SourceFileLoader rather than relying on the default
    extension-based loader resolution.
  """
  candidates = _find_command_candidates(command_name)

  incommon_candidates = [
    p
    for p in candidates
    if "/incommon/" in p
  ]

  usrbin_candidates = [
    p
    for p in candidates
    if p.startswith("/usr/bin/")
  ]

  if incommon_candidates:
    target = incommon_candidates[0]
  elif usrbin_candidates:
    raise RuntimeError(
      f"Found /usr/bin/{command_name}, but expected the incommon Python "
      f"{command_name} module on PATH."
    )
  else:
    raise RuntimeError(
      f"Could not find an incommon '{command_name}' module on PATH."
    )

  module_name = f"rt_incommon_{command_name}"

  loader = SourceFileLoader(
    module_name
    ,target
  )
  spec = importlib.util.spec_from_loader(
    module_name
    ,loader
  )
  if spec is None:
    raise RuntimeError(f"Failed to create spec for {command_name} from {target}")

  module = importlib.util.module_from_spec(spec)
  # spec.loader is the SourceFileLoader we just created
  assert spec.loader is not None
  spec.loader.exec_module(module)

  return module
