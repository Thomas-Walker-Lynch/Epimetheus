#!/usr/bin/env python3
# -*- mode: python; coding: utf-8; python-indent-offset: 2; indent-tabs-mode: nil -*-

"""
command.py - high-level dispatch for <has_other> Harmony check commands

Commands (semantics):

  structure:
    - Differences in directory structure: directories present in A but
      not present as directories in B.

  import:
    - Shell copy commands to copy:
        * in-between nodes in B that are newer than A (same relative path), or
        * in-between nodes in B that do not exist in A at all.
      Direction: B -> A
      Also emits:
        * a mkdir list (directories to create in A)
        * an "other" list for type mismatches / non-file/dir nodes.

  export:
    - Shell copy commands to copy:
        * nodes in A that are newer than B, and
        * nodes in A that do not exist in B.
      Direction: A -> B
      Also emits:
        * a mkdir list (directories to create in B)
        * an "other" list for type mismatches / non-file/dir nodes.

  suspicious:
    - Nodes in B that fall "in between" the Harmony skeleton topology:
      under some A directory, but not under any A leaf directory.
      (tree_dict_in_between_and_below(A,B).in_between)

  addendum:
    - Nodes in B that fall "below" Harmony leaf directories:
      added work in appropriate extension locations.
      (tree_dict_in_between_and_below(A,B).below)

  all:
    - Runs structure, import, export, suspicious, and addendum.
"""

from __future__ import annotations

import os
from typing import Any, Dict, List, Tuple

import skeleton

TreeDict = Dict[str, Dict[str, Any]]


def shell_quote(
  s: str
) -> str:
  """
  Minimal single-quote shell quoting.
  """
  return "'" + s.replace("'", "'\"'\"'") + "'"


def _print_header(
  title: str
) -> None:
  print()
  print(f"== {title} ==")


# ----------------------------------------------------------------------
# structure: directories in A that are missing / non-directories in B
# ----------------------------------------------------------------------
def cmd_structure(
  A: TreeDict
  ,B: TreeDict
) -> int:
  """
  structure: differences in directory structure, directories in A - B.

  We include any path where:
    - A[path].node_type == 'directory', and
    - either path not in B, or B[path].node_type != 'directory'.
  """
  structural: TreeDict = {}

  for path, info_A in A.items():
    if info_A.get("node_type") != "directory":
      continue

    info_B = B.get(path)
    if info_B is None or info_B.get("node_type") != "directory":
      structural[path] = info_A

  if not structural:
    _print_header("structure")
    print("No structural directory differences (A - B).")
    return 0

  _print_header("structure: directories in A not in B")
  skeleton.tree_dict_print(structural)
  return 0


# ----------------------------------------------------------------------
# import: B -> A (mkdir, cp, and "other" list), using in_between_newer
# ----------------------------------------------------------------------


def build_import_commands(
  A_tree: TreeDict
  ,B_tree: TreeDict
  ,A_root: str
  ,B_root: str
) -> Tuple[List[str], List[str], List[str]]:
  """
  Compute shell commands to update A from B.

  Returns:
    (mkdir_cmds, cp_cmds, other_list)

  Semantics:

    mkdir_cmds:
      - Directories that are directories in B, but are missing in A.
      - We DO NOT auto-resolve type mismatches (e.g. B=directory,
        A=file); those go into other_list.

    cp_cmds:
      - Files where:
          * the path does not exist in A, OR
          * the node in A is not a file, OR
          * the B copy is newer than A (mtime comparison).
      - However, if A has a non-file at that path, we treat it as a
        type mismatch and add that path to other_list instead of
        emitting a cp command.

    other_list:
      - Human-readable notes for:
          * type mismatches between A and B, and
          * nodes in B that are neither 'file' nor 'directory'.
  """
  mkdir_cmds: List[str] = []
  cp_cmds: List[str] = []
  other_list: List[str] = []

  for rel_path, b_info in B_tree.items():
    b_type = b_info.get("node_type")
    rel_display = rel_path if rel_path else "."

    a_info = A_tree.get(rel_path)
    a_type = a_info.get("node_type") if a_info is not None else "MISSING"

    # Case 1: B node is neither file nor directory -> other_list
    if b_type not in ("file", "directory"):
      other_list.append(
        f"{rel_display}: A={a_type}, B={b_type}"
      )
      continue

    # Case 2: B directory
    if b_type == "directory":
      if a_info is None:
        # Missing in A: copy the directory recursively.
        src = os.path.join(B_root, rel_path) if rel_path else B_root
        # The destination should be the parent directory in A.
        # os.path.join(A_root, rel_path) gives the full path to the new directory in A.
        # os.path.dirname of that gives the parent directory.
        dst = os.path.dirname(os.path.join(A_root, rel_path))
        mkdir_cmds.append(
          f"cp -a {shell_quote(src)} {shell_quote(dst + os.sep)}"
        )
      else:
        # Exists in A: must also be a directory to be "structurally OK"
        if a_type != "directory":
          # Type mismatch: do not mkdir, just report
          other_list.append(
            f"{rel_display}: A={a_type}, B=directory"
          )
      continue

    # Case 3: B file
    #   Decide whether to copy B -> A, or report conflict.
    if a_info is None:
      # B-only file
      src = os.path.join(B_root, rel_path) if rel_path else B_root
      # Destination is the parent directory in A, with a trailing slash
      dst = os.path.dirname(os.path.join(A_root, rel_path))
      cp_cmds.append(
        f"cp -a {shell_quote(src)} {shell_quote(dst + os.sep)}"
      )
      continue

    # A has something at this path
    if a_type != "file":
      # Type mismatch (e.g. A=directory, B=file, or A=other)
      other_list.append(
        f"{rel_display}: A={a_type}, B=file"
      )
      continue

    # Both files: compare mtime
    a_mtime = a_info.get("mtime")
    b_mtime = b_info.get("mtime")

    if isinstance(a_mtime, (int, float)) and isinstance(b_mtime, (int, float)):
      if b_mtime > a_mtime:
        src = os.path.join(B_root, rel_path) if rel_path else B_root
        # Destination is the parent directory in A, with a trailing slash
        dst = os.path.dirname(os.path.join(A_root, rel_path))
        cp_cmds.append(
          f"cp -a {shell_quote(src)} {shell_quote(dst + os.sep)}"
        )

  return mkdir_cmds, cp_cmds, other_list

def cmd_import(
  A_tree: TreeDict
  ,B_tree: TreeDict
  ,A_root: str
  ,B_root: str
) -> int:
  """
  import: update the skeleton (A) from the project (B),
  using only in_between_newer nodes.
  """
  inb_newer = skeleton.in_between_newer(A_tree, B_tree)

  mkdir_cmds, cp_cmds, other_list = build_import_commands(
    A_tree
    ,inb_newer
    ,A_root
    ,B_root
  )

  print("== import: copy from B -> A (in-between newer only) ==")
  print(f"# A root: {A_root}")
  print(f"# B root: {B_root}")
  print("# Only considering in-between files that are new or absent in A.")
  print("#")

  print("# Directories to copy from B -> A (cp -a):")
  if mkdir_cmds:
    for line in mkdir_cmds:
      print(line)
  else:
    print("#   (none)")
  print("#")

  print("# Files to copy from B -> A (cp -a):")
  if cp_cmds:
    for line in cp_cmds:
      print(line)
  else:
    print("#   (none)")
  print("#")

  print("# Nodes NOT handled automatically (type mismatches / non-file/dir):")
  if other_list:
    for rel in other_list:
      print(f"#   {rel}")
  else:
    print("#   (none)")

  return 0


# ----------------------------------------------------------------------
# export: A -> B (mkdir, cp, and "other" list)
# ----------------------------------------------------------------------
def build_export_commands(
  A_tree: TreeDict
  ,B_tree: TreeDict
  ,A_root: str
  ,B_root: str
) -> Tuple[List[str], List[str], List[str]]:
  """
  Compute shell commands to update B from A.

  Returns:
    (mkdir_cmds, cp_cmds, other_list)

  Semantics:

    mkdir_cmds:
      - Directories that are directories in A, but are missing in B.
      - Type mismatches go into other_list.

    cp_cmds:
      - Files where:
          * the path does not exist in B, OR
          * the node in B is not a file, OR
          * the A copy is newer than B (mtime comparison).
      - If B has a non-file while A has a file, treat as type mismatch.

    other_list:
      - Human-readable notes for:
          * type mismatches between A and B, and
          * nodes in A that are neither 'file' nor 'directory'.
  """
  mkdir_cmds: List[str] = []
  cp_cmds: List[str] = []
  other_list: List[str] = []

  # Sort keys to ensure parent directories are processed before their children.
  sorted_paths = sorted(A_tree.keys(), key=len)
  included_dirs: Set[str] = set()

  for rel_path in sorted_paths:
    a_info = A_tree[rel_path]
    a_type = a_info.get("node_type")
    rel_display = rel_path if rel_path else "."

    b_info = B_tree.get(rel_path)
    b_type = b_info.get("node_type") if b_info is not None else "MISSING"

    # Case 1: A node is neither file nor directory -> other_list
    if a_type not in ("file", "directory"):
      other_list.append(
        f"{rel_display}: A={a_type}, B={b_type}"
      )
      continue

    # Check if this path is a child of an already included directory
    is_child_of_included_dir = False
    for d in included_dirs:
      if rel_path.startswith(d + os.sep):
        is_child_of_included_dir = True
        break
    
    if is_child_of_included_dir:
      continue

    # Case 2: A directory
    if a_type == "directory":
      if b_info is None:
        # Missing in B: copy the directory recursively.
        src = os.path.join(A_root, rel_path) if rel_path else A_root
        # The destination should be the parent directory in B.
        dst = os.path.dirname(os.path.join(B_root, rel_path))
        mkdir_cmds.append(
          f"cp -a {shell_quote(src)} {shell_quote(dst + os.sep)}"
        )
        included_dirs.add(rel_path)
      else:
        # Exists in B: must also be directory
        if b_type != "directory":
          other_list.append(
            f"{rel_display}: A=directory, B={b_type}"
          )
      continue

    # Case 3: A file
    if b_info is None:
      # A-only file
      src = os.path.join(A_root, rel_path) if rel_path else A_root
      # Destination is the parent directory in B, with a trailing slash
      dst = os.path.dirname(os.path.join(B_root, rel_path))
      cp_cmds.append(
        f"cp -a {shell_quote(src)} {shell_quote(dst + os.sep)}"
      )
      continue

    if b_type != "file":
      other_list.append(
        f"{rel_display}: A=file, B={b_type}"
      )
      continue

    # Both files: compare mtime
    a_mtime = a_info.get("mtime")
    b_mtime = b_info.get("mtime")

    if isinstance(a_mtime, (int, float)) and isinstance(b_mtime, (int, float)):
      if a_mtime > b_mtime:
        src = os.path.join(A_root, rel_path) if rel_path else A_root
        # Destination is the parent directory in B, with a trailing slash
        dst = os.path.dirname(os.path.join(B_root, rel_path))
        cp_cmds.append(
          f"cp -a {shell_quote(src)} {shell_quote(dst + os.sep)}"
        )

  return mkdir_cmds, cp_cmds, other_list


def cmd_export(
  A_tree: TreeDict
  ,B_tree: TreeDict
  ,A_root: str
  ,B_root: str
) -> int:
  """
  export: show directory creation and copy commands A -> B.
  """
  mkdir_cmds, cp_cmds, other_list = build_export_commands(
    A_tree
    ,B_tree
    ,A_root
    ,B_root
  )

  print("== export: copy from A -> B ==")
  print(f"# A root: {A_root}")
  print(f"# B root: {B_root}")
  print("#")

  print("# Directories to copy from A -> B (cp -a):")
  if mkdir_cmds:
    for line in mkdir_cmds:
      print(line)
  else:
    print("#   (none)")
  print("#")

  print("# Files to copy from A -> B (cp -a):")
  if cp_cmds:
    for line in cp_cmds:
      print(line)
  else:
    print("#   (none)")
  print("#")

  print("# Nodes NOT handled automatically (type mismatches / non-file/dir):")
  if other_list:
    for rel in other_list:
      print(f"#   {rel}")
  else:
    print("#   (none)")

  return 0


# ----------------------------------------------------------------------
# suspicious / addendum via in_between_and_below
# ----------------------------------------------------------------------
def cmd_suspicious(
  A: TreeDict
  ,B: TreeDict
) -> int:
  """
  suspicious: nodes in B that fall 'in between' the Harmony skeleton,
  not under leaf directories.
  """
  in_between, _below = skeleton.tree_dict_in_between_and_below(A, B)

  _print_header("suspicious: nodes in-between Harmony leaves")

  if not in_between:
    print("No suspicious nodes found in B (relative to A).")
    return 0

  skeleton.tree_dict_print(in_between)
  return 0


def cmd_addendum(
  A: TreeDict
  ,B: TreeDict
) -> int:
  """
  addendum: nodes in B that fall 'below' Harmony leaf directories.
  """
  _in_between, below = skeleton.tree_dict_in_between_and_below(A, B)

  _print_header("addendum: nodes added under Harmony leaves")

  if not below:
    print("No addendum nodes found in B (relative to A).")
    return 0

  skeleton.tree_dict_print(below)
  return 0


# ----------------------------------------------------------------------
# Top-level dispatcher
# ----------------------------------------------------------------------
def dispatch(
  has_other_list: List[str]
  ,A: TreeDict
  ,B: TreeDict
  ,A_root: str
  ,B_root: str
) -> int:
  """
  Dispatch <has_other> commands.

  has_other_list:
    List of command tokens (subset of:
      'structure', 'import', 'export', 'suspicious', 'addendum', 'all').

  A, B:
    tree_dicts for Harmony skeleton (A) and <other> project (B).

  A_root, B_root:
    Root paths corresponding to A and B (for copy commands).
  """
  cmds = set(has_other_list)

  if "all" in cmds:
    cmds.update([
      "structure"
      ,"import"
      ,"export"
      ,"suspicious"
      ,"addendum"
    ])

  ordered = [
    "structure"
    ,"import"
    ,"export"
    ,"suspicious"
    ,"addendum"
  ]

  status = 0

  for name in ordered:
    if name not in cmds:
      continue

    if name == "structure":
      rc = cmd_structure(A, B)
    elif name == "import":
      rc = cmd_import(A, B, A_root, B_root)
    elif name == "export":
      rc = cmd_export(A, B, A_root, B_root)
    elif name == "suspicious":
      rc = cmd_suspicious(A, B)
    elif name == "addendum":
      rc = cmd_addendum(A, B)
    else:
      rc = 0

    if rc != 0:
      status = rc

  return status
