#!/usr/bin/env python3
# -*- mode: python; coding: utf-8; python-indent-offset: 2; indent-tabs-mode: nil -*-

"""
GitIgnore.py - minimal .gitignore-based helper for Harmony projects

Behavior:

  1. During initialization, traverse the project tree rooted at
     <project_path>.

  2. Whenever a directory contains a '.gitignore' file, record:
       - its relative directory path from the project root
       - a list of regular expressions compiled from the patterns
         in that '.gitignore' file

     These are stored in:

       self.rules: Dict[str, List[Pattern]]

       where the key is the directory RELATIVE to the project root:
         ""          -> project root (top-level .gitignore)
         "src"       -> src/.gitignore
         "src/module" -> src/module/.gitignore

  3. check(<path>) -> token:

       - <path> is a path relative to the project root.

       - We compute all prefix directories of <path>, including the
         root (""), for example:

           path = "a/b/c.py"
           prefixes = ["", "a", "a/b"]

       - For each prefix, if there are regexes stored for that directory,
         we collect them.

       - We then test ALL collected regexes against the basename of
         <path> (the last component only).

       - If ANY regex matches, return 'Ignore'.
         Otherwise return 'Accept'.

Notes:

  * We implement a simplified subset of .gitignore semantics suitable
    for your current patterns and add a small base ignore set for
    always-ignored names such as '.git'.
"""

from __future__ import annotations

import fnmatch
import os
import re
from typing import Dict, List
import Harmony


class GitIgnore:
  """
  GitIgnore(project_path)

  Attributes:
    project_path:
      Absolute path to the project root.

    rules:
      Mapping from relative directory path -> list of compiled regex
      patterns derived from that directory's '.gitignore' file.

      Example:
        rules[""]           -> patterns from <root>/.gitignore
        rules["developer"]  -> patterns from developer/.gitignore

    base_patterns:
      List of compiled regex patterns applied to the basename of every
      checked path, independent of any .gitignore file. Currently used
      to always ignore '.git' directories.
  """

  def __init__(
    self
    ,project_path: str
  ) -> None:
    """
    Initialize a GitIgnore instance with a path to a project and
    scan for '.gitignore' files.
    """
    self.project_path: str = os.path.abspath(project_path)
    self.rules: Dict[str, List[re.Pattern]] = {}

    # Base patterns: always applied, regardless of .gitignore contents.
    # These are matched against basenames only.
    self.base_patterns: List[re.Pattern] = [
      re.compile(r"^\.git$")    # ignore any basename == ".git"
    ]

    self._scan_project()

  def _scan_project(self) -> None:
    """
    Traverse the project tree and populate self.rules with entries of
    the form:

      <rel_dir> -> [Pattern, Pattern, ...]

    where <rel_dir> is the directory containing '.gitignore', relative
    to the project root ("" for root).
    """
    root = self.project_path

    for dirpath, dirnames, filenames in os.walk(root, topdown=True):
      if ".gitignore" not in filenames:
        continue

      rel_dir = os.path.relpath(dirpath, root)
      if rel_dir == ".":
        rel_dir = ""

      gitignore_path = os.path.join(dirpath, ".gitignore")
      patterns = self._parse_gitignore_file(gitignore_path)

      if patterns:
        if rel_dir not in self.rules:
          self.rules[rel_dir] = []
        self.rules[rel_dir].extend(patterns)

  def _parse_gitignore_file(
    self
    ,gitignore_path: str
  ) -> List[re.Pattern]:
    """
    Parse a single '.gitignore' file into a list of compiled regex patterns.

    Simplified rules:
      - Blank lines and lines starting with '#' are ignored.
      - Lines containing '/' in the MIDDLE are currently ignored
        (future extension).
      - Lines ending with '/' are treated as directory name patterns:
          '__pycache__/' -> pattern on basename '__pycache__'
      - All patterns are treated as name globs and compiled via
        fnmatch.translate(), to be matched against basenames only.
    """
    patterns: List[re.Pattern] = []

    try:
      with open(gitignore_path, "r", encoding="utf-8") as f:
        for raw_line in f:
          line = raw_line.strip()

          # Skip comments and blank lines
          if not line or line.startswith("#"):
            continue

          # Remove trailing '/' for directory patterns (e.g. '__pycache__/')
          if line.endswith("/"):
            line = line[:-1].strip()
            if not line:
              continue

          # If there is still a '/' in the line, we do not support this
          # pattern in this minimal implementation.
          if "/" in line:
            continue

          # Compile as a name glob -> regex
          regex_text = fnmatch.translate(line)
          patterns.append(re.compile(regex_text))

    except OSError:
      # If the .gitignore cannot be read, just skip it.
      return patterns

    return patterns

  def check(
    self
    ,path: str
  ) -> str:
    """
    Check a path against the collected .gitignore patterns.

    path:
      A path relative to the project root.

    Returns:
      'Ignore' if any applicable pattern matches the basename of the path,
      otherwise 'Accept'.
    """
    # Normalize the incoming path
    norm = os.path.normpath(path)

    # If the path is '.' or empty, we accept it
    if norm in ("", "."):
      return "Accept"

    basename = os.path.basename(norm)

    # First, apply base patterns (always applied).
    for pat in self.base_patterns:
      if pat.match(basename):
        return "Ignore"

    # Build the list of directories that may contribute .gitignore rules.
    #
    # For path "a/b/c":
    #   prefixes: ["", "a", "a/b"]
    parts = norm.split(os.sep)

    prefixes: List[str] = [""]
    prefix = None
    for part in parts[:-1]:
      if prefix is None:
        prefix = part
      else:
        prefix = os.path.join(prefix, part)
      prefixes.append(prefix)

    # Collect all patterns from the applicable .gitignore directories
    for rel_dir in prefixes:
      dir_patterns = self.rules.get(rel_dir)
      if not dir_patterns:
        continue

      for pat in dir_patterns:
        if pat.match(basename):
          return "Ignore"

    return "Accept"


def test_GitIgnore() -> int:
  """
    1. Locate the Harmony project root using Harmony.where().
    2. Create a GitIgnore instance rooted at that path.
    3. Print:
       - directories that have .gitignore rules
       - directories (relative) that would be ignored by check()
  """
  status, Harmony_root = Harmony.where()

  if status == "not-found":
    print("Harmony project not found; cannot test GitIgnore.")
    return 1

  if status == "different":
    print("Warning: Harmony not found, using nearest .git directory for GitIgnore test.")

  gi = GitIgnore(Harmony_root)

  print(".gitignore rule directories (relative to Harmony root):")
  for rel_dir in sorted(gi.rules.keys()):
    print(f"  {rel_dir if rel_dir else '.'}")

  print("\nDirectories that would be ignored (relative to Harmony root):")
  for dirpath, dirnames, filenames in os.walk(Harmony_root, topdown=True):
    rel_dir = os.path.relpath(dirpath, Harmony_root)
    if rel_dir == ".":
      rel_dir = ""

    if gi.check(rel_dir) == "Ignore":
      print(f"  {rel_dir if rel_dir else '.'}")

  return 0


if __name__ == "__main__":
  raise SystemExit(test_GitIgnore())
