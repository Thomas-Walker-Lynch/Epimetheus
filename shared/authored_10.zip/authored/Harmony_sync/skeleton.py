#!/usr/bin/env python3
# -*- mode: python; coding: utf-8; python-indent-offset: 2; indent-tabs-mode: nil -*-

"""
skeleton.py - helpers for working with the Harmony skeleton tree
"""

from __future__ import annotations

import os
import sys
from typing import Any, Callable, Dict, List, Set

import meta
from GitIgnore import GitIgnore
import Harmony

TreeDict = Dict[str, Dict[str, Any]]

# tree_dict_make / tree_dict_print
#
# Build a dictionary describing a project tree, respecting GitIgnore.
#
# tree_dict_make(<path>, <checksum_fn>) -> tree_dict
#
#   <checksum_fn>(<abs_path>) -> bignum | None
#
#   Keys of tree_dict:
#     - Relative paths from <path>; the root itself is stored under "".
#
#   Values are dicts with:
#     1. 'mtime'     : last modification time (float seconds) or None
#     2. 'node_type' : 'file', 'directory', 'other', or 'constrained'
#     3. 'dir_info'  : 'NA', 'leaf', 'branch', 'root'
#     4. 'checksum'  : present only for file nodes when checksum_fn is
#                      not None
#
#   Traversal:
#     - Directories whose relative path GitIgnore.check() marks as
#       'Ignore' are included in tree_dict but not traversed further.
def tree_dict_make(
  path: str
  ,checksum_fn: Callable[[str], int] | None
) -> Dict[str, Dict[str, Any]]:
  """
  Build a tree_dict for the subtree rooted at <path>, respecting GitIgnore.

  Semantics (current):
    * Any path (directory or file) for which GitIgnore.check(<rel_path>)
      returns 'Ignore' is completely omitted from the tree_dict.
    * The root directory ('') is always included.
    * Directory dir_info:
        - 'root'   for the root
        - 'branch' for directories that have child directories
                    (after GitIgnore filtering)
        - 'leaf'   for directories with no child directories
    * Non-directory dir_info:
        - 'NA'
    * Symlinks are classified as file/directory/other based on what
      they point to, if accessible.
    * If any filesystem access needed for classification/mtime raises,
      the node is recorded as node_type='constrained', dir_info='NA',
      mtime=None, and we do not attempt checksum.
  """
  root = os.path.abspath(path)
  gi = GitIgnore(root)

  tree_dict: Dict[str, Dict[str, Any]] = {}

  for dirpath, dirnames, filenames in os.walk(root, topdown=True):
    rel_dir = os.path.relpath(dirpath, root)
    if rel_dir == ".":
      rel_dir = ""

    # Skip ignored directories (except the root).
    if rel_dir != "" and gi.check(rel_dir) == "Ignore":
      dirnames[:] = []
      continue

    # Filter child directories by GitIgnore so dir_info reflects
    # only directories we will actually traverse.
    kept_dirnames: List[str] = []
    for dn in list(dirnames):
      child_rel = dn if rel_dir == "" else os.path.join(rel_dir, dn)
      if gi.check(child_rel) == "Ignore":
        dirnames.remove(dn)
      else:
        kept_dirnames.append(dn)

    # Record the directory node itself
    dir_abs = dirpath
    try:
      dir_mtime = os.path.getmtime(dir_abs)
      dir_node_type = "directory"
      if rel_dir == "":
        dir_info = "root"
      elif kept_dirnames:
        dir_info = "branch"
      else:
        dir_info = "leaf"
    except OSError:
      # Could not stat the directory: treat as constrained.
      dir_mtime = None
      dir_node_type = "constrained"
      dir_info = "NA"

    tree_dict[rel_dir] = {
      "mtime": dir_mtime
      ,"node_type": dir_node_type
      ,"dir_info": dir_info
    }

    # For non-ignored directories, record files within
    for name in filenames:
      abs_path = os.path.join(dirpath, name)
      if rel_dir == "":
        rel_path = name
      else:
        rel_path = os.path.join(rel_dir, name)

      if gi.check(rel_path) == "Ignore":
        continue

      # Wrap classification + mtime in one try/except so any failure
      # marks the node as constrained.
      try:
        if os.path.islink(abs_path):
          # Symlink: classify by target if possible
          if os.path.isdir(abs_path):
            node_type = "directory"
            dir_info_f = "branch"
          elif os.path.isfile(abs_path):
            node_type = "file"
            dir_info_f = "NA"
          else:
            node_type = "other"
            dir_info_f = "NA"
          mtime = os.path.getmtime(abs_path)
        else:
          # Normal node
          if os.path.isfile(abs_path):
            node_type = "file"
            dir_info_f = "NA"
          elif os.path.isdir(abs_path):
            node_type = "directory"
            dir_info_f = "branch"
          else:
            node_type = "other"
            dir_info_f = "NA"
          mtime = os.path.getmtime(abs_path)
      except OSError:
        # Anything that blows up during classification/stat becomes
        # constrained; we do not attempt checksum for these.
        node_type = "constrained"
        dir_info_f = "NA"
        mtime = None

      info: Dict[str, Any] = {
        "mtime": mtime
        ,"node_type": node_type
        ,"dir_info": dir_info_f
      }

      if node_type == "file" and checksum_fn is not None and isinstance(mtime, (int, float)):
        info["checksum"] = checksum_fn(abs_path)

      tree_dict[rel_path] = info

  if meta.debug_has("tree_dict_print"):
    tree_dict_print(tree_dict)

  return tree_dict

def tree_dict_print(
  tree_dict: Dict[str, Dict[str, Any]]
) -> None:
  """
  Pretty-print a tree_dict produced by tree_dict_make() in fixed-width columns:

    [type]  [dir]  [mtime]  [checksum?]  [relative path]

  Only the values are printed in each column (no 'field=' prefixes).
  mtime is formatted via the Z module for human readability.
  """
  entries: List[tuple[str, str, str, str, str]] = []
  has_checksum = False

  for rel_path in sorted(tree_dict.keys()):
    info = tree_dict[rel_path]
    display_path = rel_path if rel_path != "" else "."

    type_val = str(info.get("node_type", ""))
    dir_val = str(info.get("dir_info", ""))

    raw_mtime = info.get("mtime")
    if isinstance(raw_mtime, (int, float)):
      mtime_val = meta.z_format_mtime(raw_mtime)
    else:
      mtime_val = str(raw_mtime)

    if "checksum" in info:
      checksum_val = str(info["checksum"])
      has_checksum = True
    else:
      checksum_val = ""

    entries.append((
      type_val
      ,dir_val
      ,mtime_val
      ,checksum_val
      ,display_path
    ))

  # Compute column widths
  type_w = 0
  dir_w = 0
  mtime_w = 0
  checksum_w = 0

  for type_val, dir_val, mtime_val, checksum_val, _ in entries:
    if len(type_val) > type_w:
      type_w = len(type_val)
    if len(dir_val) > dir_w:
      dir_w = len(dir_val)
    if len(mtime_val) > mtime_w:
      mtime_w = len(mtime_val)
    if has_checksum and len(checksum_val) > checksum_w:
      checksum_w = len(checksum_val)

  print("Tree dictionary contents:")
  for type_val, dir_val, mtime_val, checksum_val, display_path in entries:
    line = "  "
    line += type_val.ljust(type_w)
    line += "  "
    line += dir_val.ljust(dir_w)
    line += "  "
    line += mtime_val.ljust(mtime_w)

    if has_checksum:
      line += "  "
      line += checksum_val.ljust(checksum_w)

    line += "  "
    line += display_path

    print(line)


def tree_dict_A_minus_B(
  A: Dict[str, Dict[str, Any]]
  ,B: Dict[str, Dict[str, Any]]
) -> Dict[str, Dict[str, Any]]:
  """
  Compute the set difference of two tree_dicts at the key level:

    Result = A \\ B

  That is, return a new tree_dict containing only those entries whose
  keys are present in A but NOT present in B.
  """
  result: Dict[str, Dict[str, Any]] = {}

  B_keys = set(B.keys())

  for key, info in A.items():
    if key not in B_keys:
      result[key] = info

  if meta.debug_has("tree_dict_A_minus_B"):
    tree_dict_print(result)

  return result


def tree_dict_in_between_and_below(
  A: Dict[str, Dict[str, Any]]
  ,B: Dict[str, Dict[str, Any]]
) -> tuple[Dict[str, Dict[str, Any]], Dict[str, Dict[str, Any]]]:
  """
  Partition nodes of B into two topology-based sets relative to A:

    1. in_between:
         Nodes in B that lie under at least one directory node in A,
         but do NOT lie under any leaf directory of A.

    2. below:
         Nodes in B that lie under at least one leaf directory of A.

  Definitions (relative to A's directory topology):

    - A directory node in A is any key whose info['node_type'] == 'directory'.

    - A leaf directory in A is a directory that has no *other* directory
      in A as a proper descendant. The project root ('') is therefore
      never a leaf (it always has descendant directories if the tree is
      non-trivial).

    - “Lies under”:
        * For a path p in B, we look at the chain of directory ancestors
          (including the root "") and, if p itself is a directory, p
          itself. Any of those that appear as directory keys in A are
          considered directory ancestors in A.

        * If any of those ancestors is a leaf in A, p goes to 'below'.
          Otherwise, if there is at least one directory ancestor in A,
          p goes to 'in_between'.

    - Nodes in B that do not lie under any directory in A are ignored.

  Returns:
    (in_between_dict, below_dict), both keyed like B and containing
    copies of the info dicts from B.
  """
  # 1. Collect all directory keys from A
  A_dir_keys: Set[str] = set(
    key for key, info in A.items()
    if info.get("node_type") == "directory"
  )

  # 2. Compute leaf directories in A
  leaf_dirs: Set[str] = set()

  for d in A_dir_keys:
    if d == "":
      continue

    has_child_dir = False
    prefix = d + os.sep

    for other in A_dir_keys:
      if other == d:
        continue
      if other.startswith(prefix):
        has_child_dir = True
        break

    if not has_child_dir:
      leaf_dirs.add(d)

  in_between: Dict[str, Dict[str, Any]] = {}
  below: Dict[str, Dict[str, Any]] = {}

  for key, info in B.items():
    # Skip B's root
    if key in ("", "."):
      continue

    parts = key.split(os.sep)

    # Build directory ancestor chain
    node_is_dir = (info.get("node_type") == "directory")

    ancestors: List[str] = [""]
    prefix = None

    if node_is_dir:
      upto = parts
    else:
      upto = parts[:-1]

    for part in upto:
      if prefix is None:
        prefix = part
      else:
        prefix = os.path.join(prefix, part)
      ancestors.append(prefix)

    # Filter ancestors to those that exist as directories in A
    ancestors_in_A = [d for d in ancestors if d in A_dir_keys]

    if not ancestors_in_A:
      # This B node is not under any directory from A; ignore it.
      continue

    # Any leaf ancestor in A?
    has_leaf_ancestor = any(d in leaf_dirs for d in ancestors_in_A)

    if has_leaf_ancestor:
      below[key] = info
    else:
      in_between[key] = info

  if meta.debug_has("tree_dict_in_between_and_below"):
    merged: Dict[str, Dict[str, Any]] = {}
    merged.update(in_between)
    merged.update(below)
    tree_dict_print(merged)

  return in_between, below


def tree_dict_newer(
  A: Dict[str, Dict[str, Any]]
  ,B: Dict[str, Dict[str, Any]]
) -> Dict[str, Dict[str, Any]]:
  """
  Return a dictionary of nodes from B that are newer than their
  corresponding nodes in A.

  For each key k:

    - If k exists in both A and B, and
    - B[k]['mtime'] > A[k]['mtime'],

  then k is included in the result with value B[k].

  Keys that are only in B (not in A) are ignored here.
  """
  result: Dict[str, Dict[str, Any]] = {}

  for key, info_B in B.items():
    info_A = A.get(key)
    if info_A is None:
      continue

    mtime_A = info_A.get("mtime")
    mtime_B = info_B.get("mtime")

    if mtime_A is None or mtime_B is None:
      continue

    if mtime_B > mtime_A:
      result[key] = info_B

  if meta.debug_has("tree_dict_newer"):
    tree_dict_print(result)

  return result


def tree_dict_older(
  A: Dict[str, Dict[str, Dict[str, Any]]]
  ,B: Dict[str, Dict[str, Dict[str, Any]]]
) -> Dict[str, Dict[str, Any]]:
  """
  Return a dictionary of nodes from B that are older than their
  corresponding nodes in A.

  For each key k:

    - If k exists in both A and B, and
    - B[k]['mtime'] < A[k]['mtime'],

  then k is included in the result with value B[k].

  Keys that are only in B (not in A) are ignored here.
  """
  result: Dict[str, Dict[str, Any]] = {}

  for key, info_B in B.items():
    info_A = A.get(key)
    if info_A is None:
      continue

    mtime_A = info_A.get("mtime")
    mtime_B = info_B.get("mtime")

    if mtime_A is None or mtime_B is None:
      continue

    if mtime_B < mtime_A:
      result[key] = info_B

  if meta.debug_has("tree_dict_older"):
    tree_dict_print(result)

  return result

def in_between_newer(
  A: TreeDict
  ,B: TreeDict
) -> TreeDict:
  """
  in_between_newer(A, B) -> TreeDict

  Return the subset of B's nodes that:

    1. Are in the 'in_between' region with respect to A's topology:
         - under some directory that exists in A
         - NOT under any leaf directory in A
       (as defined by tree_dict_in_between_and_below), and

    2. For file nodes:
         - are "newer" than A at the same path, or
         - are absent from A.

       More precisely:
         - If A has no entry for that path -> include.
         - If A has a non-file and B has a file -> include.
         - If both are files and B.mtime > A.mtime -> include.

    3. For constrained nodes:
         - are always included, so that higher-level commands (e.g.
           'import') can surface them as "not handled automatically".

  Notes:
    - Only file nodes participate in mtime comparisons.
    - Nodes with node_type == 'constrained' are passed through without
      mtime checks, so that callers can report them separately.
  """
  in_between, _below = tree_dict_in_between_and_below(A, B)

  result: TreeDict = {}

  # Keep track of directories already included in the result
  included_dirs: Set[str] = set()

  # Sort keys to ensure parent directories are processed before their children.
  # This is crucial for the child exclusion logic to work correctly.
  sorted_paths = sorted(in_between.keys(), key=len)

  for path in sorted_paths:
    b_info = in_between[path]
    b_type = b_info.get("node_type")

    # Constrained nodes: always surface so the caller can list them
    # under "not handled automatically".
    # Check if this path is a child of an already included directory
    is_child_of_included_dir = False
    for d in included_dirs:
      if path.startswith(d + os.sep):
        is_child_of_included_dir = True
        break
    
    if is_child_of_included_dir:
      continue

    # Constrained nodes: always surface so the caller can list them
    # under "not handled automatically".
    if b_type == "constrained":
      result[path] = b_info
      if b_type == "directory":
        included_dirs.add(path)
      continue



    b_mtime = b_info.get("mtime")
    a_info = A.get(path)

    # Case 1: path not in A at all -> include (new file/dir in in-between)
    if a_info is None:
      result[path] = b_info
      if b_type == "directory":
        included_dirs.add(path)
      continue

    # We only do "newer" semantics for regular files.
    if b_type != "file":
      continue

    a_type = a_info.get("node_type")

    # Case 2: A has non-file, B has file -> include
    if a_type != "file":
      result[path] = b_info
      # Note: b_type must be "file" here due to the check above, so no need
      # to check for directory inclusion.
      continue

    # Case 3: both are files; compare mtime
    a_mtime = a_info.get("mtime")
    if (
      isinstance(a_mtime, (int, float))
      and isinstance(b_mtime, (int, float))
      and b_mtime > a_mtime
    ):
      result[path] = b_info
      # Note: b_type must be "file" here, so no need to check for directory inclusion.

  if meta.debug_has("in_between_newer"):
    tree_dict_print(result)

  return result

