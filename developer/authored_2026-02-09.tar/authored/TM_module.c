/*
  TM_module.c
  CPython Extension: The Base Machine (Right-Only, Non-Destructive)
  Structured for Feature Selection / Mixin Architecture.
*/

#define PY_SSIZE_T_CLEAN
#include <Python.h>
#include "structmember.h"
#include <stddef.h> 

/* ========================================================= */
/* 1. DATA LAYOUT (Shared by all TM types)                   */
/* ========================================================= */

typedef struct {
  PyObject_HEAD
  PyObject* tape_obj;      /* The Python List (Shared) */
  PyObject* peer_list;     /* List of WeakRefs (Shared) */
  Py_ssize_t head;         /* Raw Instruction Pointer */
  PyObject* weakreflist;   /* Required for WeakRefs */
} FastTM;

/* Forward Deallocator (Common) */
static void FastTM_dealloc(FastTM* self){
  if( self->weakreflist != NULL ){
    PyObject_ClearWeakRefs((PyObject*)self);
  }
  Py_XDECREF(self->tape_obj);
  Py_XDECREF(self->peer_list);
  Py_TYPE(self)->tp_free((PyObject*)self);
}

/* Helper: Register Entanglement (Common) */
static int register_entanglement(FastTM* self, PyObject* existing_peer_list){
  PyObject* weak_ref = NULL;
  if( existing_peer_list ){
    self->peer_list = existing_peer_list;
    Py_INCREF(self->peer_list);
  } else {
    self->peer_list = PyList_New(0);
    if( !self->peer_list ) return -1;
  }
  weak_ref = PyWeakref_NewRef((PyObject*)self, NULL);
  if( !weak_ref ) return -1;
  if( PyList_Append(self->peer_list, weak_ref) < 0 ){
    Py_DECREF(weak_ref);
    return -1;
  }
  Py_DECREF(weak_ref);
  return 0;
}

/* ========================================================= */
/* 2. THE MIXIN LIBRARY (Static C Functions)                 */
/* These are the raw implementations.                        */
/* ========================================================= */

/* Mixin: Navigation (Right) */
static PyObject* mixin_s(FastTM* self){
  /* No checks. Pure speed. */
  self->head++;
  Py_RETURN_NONE;
}

static PyObject* mixin_sn(FastTM* self, PyObject* arg_tuple){
  Py_ssize_t n_val;
  if( !PyArg_ParseTuple(arg_tuple, "n", &n_val) ) return NULL;
  
  if (n_val < 0) {
      /* Base Machine does not support negative n */
      PyErr_SetString(PyExc_ValueError, "Base Machine supports positive steps only.");
      return NULL;
  }
  
  self->head += n_val;
  Py_RETURN_NONE;
}

/* Mixin: Read */
static PyObject* mixin_r(FastTM* self){
  /* Fast access. Note: PyList_GetItem does bounds checking implicitly 
     by returning NULL if out of bounds, but we rely on TM logic to stay valid. */
  PyObject* item_obj = PyList_GetItem(self->tape_obj, self->head);
  if( !item_obj ) return NULL; 
  Py_INCREF(item_obj);
  return item_obj;
}

static PyObject* mixin_rn(FastTM* self, PyObject* arg_tuple){
  Py_ssize_t n_val;
  if( !PyArg_ParseTuple(arg_tuple, "n", &n_val) ) return NULL;
  return PyList_GetSlice(self->tape_obj, self->head, self->head + n_val);
}

/* Mixin: Write */
static PyObject* mixin_w(FastTM* self, PyObject* val_obj){
  Py_INCREF(val_obj);
  /* PyList_SetItem steals the reference, so we INCREF first */
  if( PyList_SetItem(self->tape_obj, self->head, val_obj) < 0 ) return NULL;
  Py_RETURN_NONE;
}

static PyObject* mixin_wn(FastTM* self, PyObject* arg_tuple){
  PyObject* val_list;
  if( !PyArg_ParseTuple(arg_tuple, "O", &val_list) ) return NULL;
  Py_ssize_t len_val = PySequence_Size(val_list);
  if( PyList_SetSlice(self->tape_obj, self->head, self->head + len_val, val_list) < 0 ) return NULL;
  Py_RETURN_NONE;
}

/* Mixin: Meta (Entangle, Query) */
static PyObject* mixin_e(FastTM* self){
  /* We use Py_TYPE(self) to ensure the entangled clone 
     is the SAME C-TYPE (Interface) as the parent */
  PyObject* arg_tuple = PyTuple_Pack(1, self);
  PyObject* new_obj = PyObject_CallObject((PyObject*)Py_TYPE(self), arg_tuple);
  Py_DECREF(arg_tuple);
  return new_obj;
}

static PyObject* mixin_address(FastTM* self){
  return PyLong_FromSsize_t(self->head);
}

static PyObject* mixin_len(FastTM* self){
  return PyLong_FromSsize_t(PyList_Size(self->tape_obj));
}

static PyObject* mixin_rightmost(FastTM* self){
  Py_ssize_t len = PyList_Size(self->tape_obj);
  if( self->head >= len - 1 ) Py_RETURN_TRUE;
  Py_RETURN_FALSE;
}

/* ========================================================= */
/* 3. INTERFACE CONSTRUCTION (The Base Type)                 */
/* ========================================================= */

/* Constructor logic:
   Takes (container, features_list).
   
   FUTURE: This is where we will check 'features_list' and 
   set self->ob_type to FastTM_BiDirType, FastTM_DestructiveType, etc.
   
   CURRENT: We enforce Base Machine rules (Right-Only, Non-Destructive).
*/
static int BaseTM_init(FastTM* self, PyObject* args, PyObject* kwds){
  PyObject* input_obj = NULL;
  PyObject* features_obj = NULL; 
  
  if( !PyArg_ParseTuple(args, "O|O", &input_obj, &features_obj) ) return -1;
  
  /* CLONE MODE (Entangle) */
  if( PyObject_TypeCheck(input_obj, Py_TYPE(self)) ){
    FastTM* source_tm = (FastTM*)input_obj;
    self->tape_obj = source_tm->tape_obj;
    Py_INCREF(self->tape_obj);
    self->head = source_tm->head;
    if( register_entanglement(self, source_tm->peer_list) < 0 ) return -1;
  } 
  /* NEW MODE (Container) */
  else {
    if( PyList_Check(input_obj) ){
      self->tape_obj = input_obj;
      Py_INCREF(self->tape_obj);
    } else {
      self->tape_obj = PySequence_List(input_obj);
      if( !self->tape_obj ) return -1;
    }
    
    /* Enforce Non-Empty Contract for First Order TM */
    if (PyList_Size(self->tape_obj) == 0) {
        PyErr_SetString(PyExc_ValueError, "First Order TM cannot be empty.");
        return -1;
    }

    self->head = 0;
    if( register_entanglement(self, NULL) < 0 ) return -1;
  }
  return 0;
}

/* The Method Table for the Base Machine 
   Notice: NO 'ls', NO 'd'. They do not exist here.
*/
static PyMethodDef BaseTM_methods[] = {
  {"r", (PyCFunction)mixin_r, METH_NOARGS, ""},
  {"rn", (PyCFunction)mixin_rn, METH_VARARGS, ""},
  {"w", (PyCFunction)mixin_w, METH_O, ""},
  {"wn", (PyCFunction)mixin_wn, METH_VARARGS, ""},
  {"s", (PyCFunction)mixin_s, METH_NOARGS, ""},
  {"sn", (PyCFunction)mixin_sn, METH_VARARGS, ""},
  {"e", (PyCFunction)mixin_e, METH_NOARGS, ""},
  {"address", (PyCFunction)mixin_address, METH_NOARGS, ""},
  {"len", (PyCFunction)mixin_len, METH_NOARGS, ""},
  {"rightmost", (PyCFunction)mixin_rightmost, METH_NOARGS, ""},
  {NULL}
};

static PyTypeObject BaseTMType = {
  PyVarObject_HEAD_INIT(NULL, 0)
  .tp_name = "TM_module.FastTM", /* Exposed as FastTM for now */
  .tp_doc = "Base Tape Machine (Right-Only)",
  .tp_basicsize = sizeof(FastTM),
  .tp_itemsize = 0,
  .tp_flags = Py_TPFLAGS_DEFAULT | Py_TPFLAGS_BASETYPE,
  .tp_new = PyType_GenericNew,
  .tp_init = (initproc)BaseTM_init,
  .tp_dealloc = (destructor)FastTM_dealloc,
  .tp_methods = BaseTM_methods,
  .tp_weaklistoffset = offsetof(FastTM, weakreflist)
};

/* Module Init */
static PyModuleDef TM_module = {
  PyModuleDef_HEAD_INIT, "TM_module", "Fast TM Extension", -1, NULL
};

PyMODINIT_FUNC PyInit_TM_module(void){
  PyObject* m_obj;
  if( PyType_Ready(&BaseTMType) < 0 ) return NULL;

  m_obj = PyModule_Create(&TM_module);
  if( !m_obj ) return NULL;

  Py_INCREF(&BaseTMType);
  /* We export it as FastTM to maintain compatibility with existing python code */
  PyModule_AddObject(m_obj, "FastTM", (PyObject*)&BaseTMType);
  return m_obj;
}
