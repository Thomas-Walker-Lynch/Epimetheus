#!/usr/bin/env python3
import sys
from enum import Enum, auto

try:
  import TM_module
except ImportError:
  print("Error: Import failed. Run 'python3 setup.py build_ext --inplace'")
  sys.exit(1)

# ==========================================
# 1. Enums
# ==========================================

LM = "LM"
RM = "RM"

class Status(Enum):
  ABANDONED = auto()
  ACTIVE = auto()
  EMPTY = auto()

class Topology(Enum):
  CIRCLE = auto()
  LINEAR_RIGHT = auto()
  LINEAR_OPEN = auto()
  NULL = auto()
  SEGMENT = auto()

# ==========================================
# 2. The Machine (Factory Alias)
# ==========================================

TM = TM_module.FastTM

# ==========================================
# 3. Status Wrapper (TMS)
# ==========================================

class TMS: # Renamed from TM2
  def __init__(self, data_obj=None, features=None):
    if data_obj:
      # Pass features to C constructor (future-proofing)
      # For now, BaseTM ignores the second arg or treats it as optional
      if features:
        self.tm = TM(data_obj, features)
      else:
        self.tm = TM(data_obj)
      self._stat = Status.ACTIVE
    else:
      self.tm = None
      self._stat = Status.EMPTY

  # Delegate to Inner TM
  def r(self): return self.tm.r()
  def rn(self, n_val): return self.tm.rn(n_val)
  def w(self, val_obj): return self.tm.w(val_obj)
  def wn(self, val_obj): return self.tm.wn(val_obj)
  def s(self): return self.tm.s()
  def sn(self, n_val): return self.tm.sn(n_val)
  
  # These will FAIL on Base Machine (AttributeError) until features enabled
  def ls(self): return self.tm.ls() 
  def lsn(self, n_val): return self.tm.lsn(n_val)
  def d(self): return self.tm.d()
  def dn(self, n_val): return self.tm.dn(n_val)
  def esd(self): return self.tm.esd()
  def esdn(self, n_val): return self.tm.esdn(n_val)
  def aL(self, val_obj): return self.tm.aL(val_obj)
  def aR(self, val_obj): return self.tm.aR(val_obj)

  def e(self): 
    return TMS(self.tm.e()) if not self.empty() else TMS(None)
    
  def empty(self): return self._stat == Status.EMPTY
  def rightmost(self): return True if self.empty() else self.tm.rightmost()
  # leftmost/address exist on BaseTM
  def leftmost(self): return True if self.empty() else (self.tm.head == 0) 
  def address(self): return 0 if self.empty() else self.tm.address()
  def topology(self): return Topology.NULL if self.empty() else Topology.SEGMENT
